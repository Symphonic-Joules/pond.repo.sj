const { spawn } = require('child_process');

console.log('Starting servers...');

// Start backend
const backend = spawn('npx', ['tsx', 'server/index.ts'], { 
  stdio: 'inherit' 
});

// Start frontend
const frontend = spawn('npx', ['vite', '--host', '0.0.0.0', '--port', '5173'], {
  cwd: './client',
  stdio: 'inherit'
});

console.log('Servers started - Backend:3000, Frontend:5173');