import { 
  PondTranslation, 
  InsertPondTranslation, 
  Node, 
  InsertNode, 
  ChatMessage, 
  InsertChatMessage,
  pondTranslations,
  nodes,
  chatMessages
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc } from "drizzle-orm";

export interface IStorage {
  // Pond Translation methods
  getPondTranslations(): Promise<PondTranslation[]>;
  addPondTranslation(translation: InsertPondTranslation): Promise<PondTranslation>;
  updatePondTranslation(id: string, updates: Partial<PondTranslation>): Promise<PondTranslation | null>;
  
  // Node monitoring methods
  getNodes(): Promise<Node[]>;
  getNode(id: string): Promise<Node | null>;
  addNode(node: InsertNode): Promise<Node>;
  updateNode(id: string, updates: Partial<Node>): Promise<Node | null>;
  
  // Chat methods
  getChatMessages(): Promise<ChatMessage[]>;
  addChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
}

export class DatabaseStorage implements IStorage {
  // Pond Translation methods
  async getPondTranslations(): Promise<PondTranslation[]> {
    return await db.select().from(pondTranslations).orderBy(desc(pondTranslations.timestamp));
  }

  async addPondTranslation(translation: InsertPondTranslation): Promise<PondTranslation> {
    const [newTranslation] = await db
      .insert(pondTranslations)
      .values(translation)
      .returning();
    return newTranslation;
  }

  async updatePondTranslation(id: string, updates: Partial<PondTranslation>): Promise<PondTranslation | null> {
    const [updatedTranslation] = await db
      .update(pondTranslations)
      .set(updates)
      .where(eq(pondTranslations.id, id))
      .returning();
    return updatedTranslation || null;
  }

  // Node monitoring methods
  async getNodes(): Promise<Node[]> {
    return await db.select().from(nodes);
  }

  async getNode(id: string): Promise<Node | null> {
    const [node] = await db.select().from(nodes).where(eq(nodes.id, id));
    return node || null;
  }

  async addNode(node: InsertNode): Promise<Node> {
    const [newNode] = await db
      .insert(nodes)
      .values(node)
      .returning();
    return newNode;
  }

  async updateNode(id: string, updates: Partial<Node>): Promise<Node | null> {
    const [updatedNode] = await db
      .update(nodes)
      .set({ ...updates, lastUpdated: new Date() })
      .where(eq(nodes.id, id))
      .returning();
    return updatedNode || null;
  }

  // Chat methods
  async getChatMessages(): Promise<ChatMessage[]> {
    return await db.select().from(chatMessages).orderBy(asc(chatMessages.timestamp));
  }

  async addChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [newMessage] = await db
      .insert(chatMessages)
      .values(message)
      .returning();
    return newMessage;
  }
}

export const storage = new DatabaseStorage();

// Add some initial demo data
storage.addNode({
  name: "Node Alpha",
  status: "online",
  cpu: 45,
  memory: 67,
  disk: 23,
  network: 1024,
  uptime: 86400,
});

storage.addNode({
  name: "Node Beta",
  status: "warning",
  cpu: 89,
  memory: 34,
  disk: 78,
  network: 512,
  uptime: 43200,
});

storage.addNode({
  name: "Node Gamma",
  status: "offline",
  cpu: 0,
  memory: 0,
  disk: 0,
  network: 0,
  uptime: 0,
});

storage.addPondTranslation({
  original: "Hello world",
  translated: "Hola mundo",
  language: "Spanish",
  status: "completed",
});

storage.addPondTranslation({
  original: "Welcome to the pond",
  translated: "Bienvenue dans l'étang",
  language: "French",
  status: "completed",
});

storage.addChatMessage({
  content: "Welcome to the pond translator chat!",
  sender: "System",
  type: "system",
});