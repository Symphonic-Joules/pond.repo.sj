import { Express } from "express";
import { z } from "zod";
import { insertPondTranslationSchema, insertNodeSchema, insertChatMessageSchema } from "@shared/schema";
import { storage } from "./storage";

export function registerRoutes(app: Express) {
  // Pond translation routes
  app.get("/api/pond-translations", async (req, res) => {
    try {
      const translations = await storage.getPondTranslations();
      res.json(translations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch translations" });
    }
  });

  app.post("/api/pond-translations", async (req, res) => {
    try {
      const data = insertPondTranslationSchema.parse(req.body);
      const translation = await storage.addPondTranslation(data);
      res.json(translation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create translation" });
      }
    }
  });

  app.patch("/api/pond-translations/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const translation = await storage.updatePondTranslation(id, updates);
      if (!translation) {
        res.status(404).json({ error: "Translation not found" });
        return;
      }
      res.json(translation);
    } catch (error) {
      res.status(500).json({ error: "Failed to update translation" });
    }
  });

  // Node monitoring routes
  app.get("/api/nodes", async (req, res) => {
    try {
      const nodes = await storage.getNodes();
      res.json(nodes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch nodes" });
    }
  });

  app.get("/api/nodes/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const node = await storage.getNode(id);
      if (!node) {
        res.status(404).json({ error: "Node not found" });
        return;
      }
      res.json(node);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch node" });
    }
  });

  app.post("/api/nodes", async (req, res) => {
    try {
      const data = insertNodeSchema.parse(req.body);
      const node = await storage.addNode(data);
      res.json(node);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create node" });
      }
    }
  });

  app.patch("/api/nodes/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const node = await storage.updateNode(id, updates);
      if (!node) {
        res.status(404).json({ error: "Node not found" });
        return;
      }
      res.json(node);
    } catch (error) {
      res.status(500).json({ error: "Failed to update node" });
    }
  });

  // Chat routes
  app.get("/api/chat/messages", async (req, res) => {
    try {
      const messages = await storage.getChatMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  app.post("/api/chat/messages", async (req, res) => {
    try {
      const data = insertChatMessageSchema.parse(req.body);
      const message = await storage.addChatMessage(data);
      res.json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create message" });
      }
    }
  });

  // Pond translation simulation endpoint
  app.post("/api/pond-translate", async (req, res) => {
    try {
      const { text, targetLanguage } = req.body;
      
      // Simulate translation processing
      const translation = await storage.addPondTranslation({
        original: text,
        translated: `[${targetLanguage}] ${text}`, // Placeholder translation
        language: targetLanguage,
        status: "pending",
      });

      // Simulate async processing
      setTimeout(async () => {
        await storage.updatePondTranslation(translation.id, {
          translated: `Translated: ${text} (${targetLanguage})`,
          status: "completed",
        });
      }, 2000);

      res.json(translation);
    } catch (error) {
      res.status(500).json({ error: "Translation failed" });
    }
  });
}