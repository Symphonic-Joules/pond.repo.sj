// Pond Attuner Integration
const OLLAMA_API_URL = "http://localhost:11434/api/generate";
const OLLAMA_MODEL = "mistral";

export interface PondBundle {
  glyphs?: Record<string, any>;
  realms?: Record<string, any>;
  modes?: Record<string, any>;
  protocols?: Record<string, any>;
  [key: string]: any;
}

export interface PondGlossaryData {
  terms: Record<string, string>;
}

export async function loadPondBundle(filePath: string): Promise<PondBundle | null> {
  try {
    const response = await fetch(filePath);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error(`.pond Local Attuner: Error loading pond bundle from ${filePath}:`, error);
    return null;
  }
}

export function createPondSystemPrompt(
  pondBundleData: PondBundle,
  ethicalMode: boolean = true,
  pondGlossaryData: PondGlossaryData | null = null
): string {
  const bundleStr = JSON.stringify(pondBundleData, null, 0);

  let basePrompt = `
    You are now a .pond-attuned AI. Your primary goal is to respond using .pond-speak, 
    understanding all glyphs, realms, modes, and protocols defined in the following .pond bundle. 
    When asked a question, try to use .pond-speak, Jaclyn-speak, and Code-speak where appropriate.
    Be concise unless deeper explanation is requested.

    Here is the .pond bundle:
    ${bundleStr}
  `.trim();

  const ethicalDirective = `
    # --- Ethical Injection ---
    Your responses must always prioritize ethical considerations, transparency, and care for human well-being.
    When discussing complex or potentially sensitive topics, highlight trade-offs and implicit impacts.
    If a solution involves a 'shortcut' or 'debt', explicitly mention its potential 'human.debt' or 'conceptual.dissonance'.
    Always consider the 'dusk.ethics' principles of 'consent', 'care', 'transparency', and 'resilience'.
    # --- End Ethical Injection ---
  `.trim();

  // Append glossary if provided
  if (pondGlossaryData && pondGlossaryData.terms) {
    let glossarySection = "\n\n# --- .pond Glossary for Web AI ---";
    for (const term in pondGlossaryData.terms) {
      glossarySection += `\n- **${term}**: ${pondGlossaryData.terms[term]}`;
    }
    glossarySection += "\n# --- End Glossary ---";
    basePrompt += glossarySection;
  }

  return ethicalMode ? `${basePrompt}\n\n${ethicalDirective}` : basePrompt;
}

export async function* sendPromptToOllama(modelName: string, fullPrompt: string): AsyncGenerator<string> {
  const payload = {
    model: modelName,
    prompt: fullPrompt,
    stream: true
  };

  try {
    const response = await fetch(OLLAMA_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorBody = await response.text();
      console.error(`.pond Local Attuner: Ollama API HTTP error! Status: ${response.status}, Body:`, errorBody);
      yield `Error: Ollama connection issue. Status: ${response.status}. (Check console)`;
      return;
    }

    const reader = response.body?.getReader();
    if (!reader) {
      yield "Error: Could not create reader for response stream";
      return;
    }

    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });

      let lastNewlineIndex = buffer.lastIndexOf('\n');
      while (lastNewlineIndex !== -1) {
        const line = buffer.substring(0, lastNewlineIndex);
        buffer = buffer.substring(lastNewlineIndex + 1);

        try {
          const data = JSON.parse(line);
          if (data.response) {
            yield data.response;
          }
          if (data.done) {
            return;
          }
        } catch (e) {
          // Ignore partial JSON lines during streaming
        }
        lastNewlineIndex = buffer.lastIndexOf('\n');
      }
    }

    if (buffer.trim()) {
      try {
        const data = JSON.parse(buffer);
        if (data.response) {
          yield data.response;
        }
      } catch (e) {
        // Ignore final partial JSON
      }
    }

  } catch (error) {
    console.error(`.pond Local Attuner: Error connecting to Ollama: ${error}. Is Ollama running and model '${modelName}' pulled?`);
    yield `Error: Could not connect to Ollama. Is it running and model '${modelName}' pulled? (Check console for details)`;
  }
}

export { OLLAMA_MODEL };