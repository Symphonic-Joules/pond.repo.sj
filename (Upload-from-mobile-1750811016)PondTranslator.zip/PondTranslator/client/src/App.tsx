import { QueryClientProvider } from "@tanstack/react-query";
import { Route, Switch } from "wouter";
import { queryClient } from "@/lib/queryClient";
import { Navigation } from "@/components/Navigation";
import { PondTranslator } from "@/pages/PondTranslator";
import { NodeMonitor } from "@/pages/NodeMonitor";
import { ChatInterface } from "@/pages/ChatInterface";
import { Dashboard } from "@/pages/Dashboard";

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-background">
        <Navigation />
        <main className="container mx-auto px-4 py-8">
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/pond" component={PondTranslator} />
            <Route path="/nodes" component={NodeMonitor} />
            <Route path="/chat" component={ChatInterface} />
          </Switch>
        </main>
      </div>
    </QueryClientProvider>
  );
}

export default App;