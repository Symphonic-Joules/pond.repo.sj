import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Activity, Cpu, HardDrive, Wifi, Clock } from "lucide-react";
import { Node } from "@shared/schema";

export function NodeMonitor() {
  const { data: nodes, isLoading } = useQuery<Node[]>({
    queryKey: ["/api/nodes"],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online":
        return "bg-green-500";
      case "warning":
        return "bg-yellow-500";
      case "offline":
        return "bg-red-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "online":
        return "default";
      case "warning":
        return "secondary";
      case "offline":
        return "destructive";
      default:
        return "outline";
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Node Monitor</h1>
        <p>Loading node data...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Activity className="h-8 w-8 text-blue-600" />
        <h1 className="text-3xl font-bold">Node Monitor</h1>
      </div>

      <div className="grid gap-6">
        {nodes?.map((node) => (
          <Card key={node.id} className="relative">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full ${getStatusColor(node.status)}`} />
                  {node.name}
                </CardTitle>
                <Badge variant={getStatusVariant(node.status)}>
                  {node.status.toUpperCase()}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* CPU Usage */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Cpu className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">CPU</span>
                  </div>
                  <Progress value={node.cpu} className="h-2" />
                  <p className="text-xs text-muted-foreground">{node.cpu}%</p>
                </div>

                {/* Memory Usage */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Activity className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">Memory</span>
                  </div>
                  <Progress value={node.memory} className="h-2" />
                  <p className="text-xs text-muted-foreground">{node.memory}%</p>
                </div>

                {/* Disk Usage */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <HardDrive className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">Disk</span>
                  </div>
                  <Progress value={node.disk} className="h-2" />
                  <p className="text-xs text-muted-foreground">{node.disk}%</p>
                </div>

                {/* Network & Uptime */}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Wifi className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">Network</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {node.network} KB/s
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">Uptime</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {formatUptime(node.uptime)}
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t">
                <p className="text-xs text-muted-foreground">
                  Last updated: {node.lastUpdated.toLocaleString()}
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {!nodes?.length && (
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">No nodes available</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}