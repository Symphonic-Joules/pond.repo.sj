import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, MessageSquare, Waves, AlertTriangle } from "lucide-react";
import { Node, PondTranslation, ChatMessage } from "@shared/schema";

export function Dashboard() {
  const { data: nodes } = useQuery<Node[]>({ queryKey: ["/api/nodes"] });
  const { data: translations } = useQuery<PondTranslation[]>({ 
    queryKey: ["/api/pond-translations"] 
  });
  const { data: messages } = useQuery<ChatMessage[]>({ 
    queryKey: ["/api/chat/messages"] 
  });

  const onlineNodes = nodes?.filter(n => n.status === "online").length || 0;
  const totalNodes = nodes?.length || 0;
  const recentTranslations = translations?.slice(0, 3) || [];
  const recentMessages = messages?.slice(-3) || [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Dashboard</h1>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Nodes</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{onlineNodes}/{totalNodes}</div>
            <p className="text-xs text-muted-foreground">
              {totalNodes > 0 ? `${Math.round((onlineNodes / totalNodes) * 100)}% online` : "No nodes"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Translations</CardTitle>
            <Waves className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{translations?.length || 0}</div>
            <p className="text-xs text-muted-foreground">Total processed</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Chat Messages</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{messages?.length || 0}</div>
            <p className="text-xs text-muted-foreground">Total messages</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">System Status</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">Healthy</div>
            <p className="text-xs text-muted-foreground">All systems operational</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Recent Translations</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {recentTranslations.map((translation) => (
              <div key={translation.id} className="flex items-center justify-between text-sm">
                <span className="truncate">{translation.original}</span>
                <span className={`px-2 py-1 rounded text-xs ${
                  translation.status === "completed" 
                    ? "bg-green-100 text-green-800" 
                    : translation.status === "pending"
                    ? "bg-yellow-100 text-yellow-800"
                    : "bg-red-100 text-red-800"
                }`}>
                  {translation.status}
                </span>
              </div>
            ))}
            {recentTranslations.length === 0 && (
              <p className="text-sm text-muted-foreground">No translations yet</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Node Overview</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {nodes?.slice(0, 3).map((node) => (
              <div key={node.id} className="flex items-center justify-between text-sm">
                <span>{node.name}</span>
                <span className={`px-2 py-1 rounded text-xs ${
                  node.status === "online" 
                    ? "bg-green-100 text-green-800" 
                    : node.status === "warning"
                    ? "bg-yellow-100 text-yellow-800"
                    : "bg-red-100 text-red-800"
                }`}>
                  {node.status}
                </span>
              </div>
            ))}
            {!nodes?.length && (
              <p className="text-sm text-muted-foreground">No nodes available</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Chat</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {recentMessages.map((message) => (
              <div key={message.id} className="text-sm">
                <div className="flex items-center gap-2">
                  <span className="font-medium">{message.sender}</span>
                  <span className="text-xs text-muted-foreground">
                    {message.timestamp.toLocaleTimeString()}
                  </span>
                </div>
                <p className="text-muted-foreground truncate">{message.content}</p>
              </div>
            ))}
            {recentMessages.length === 0 && (
              <p className="text-sm text-muted-foreground">No messages yet</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}