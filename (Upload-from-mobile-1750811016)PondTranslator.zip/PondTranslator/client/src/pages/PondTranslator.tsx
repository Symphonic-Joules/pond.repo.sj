import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Waves, Send, RefreshCw } from "lucide-react";
import { PondTranslation, InsertPondTranslation } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

export function PondTranslator() {
  const [inputText, setInputText] = useState("");
  const [targetLanguage, setTargetLanguage] = useState("");

  const { data: translations, isLoading } = useQuery<PondTranslation[]>({
    queryKey: ["/api/pond-translations"],
    refetchInterval: 2000, // Refresh every 2 seconds to show status updates
  });

  const translateMutation = useMutation({
    mutationFn: (data: { text: string; targetLanguage: string }) =>
      apiRequest("/api/pond-translate", {
        method: "POST",
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pond-translations"] });
      setInputText("");
      setTargetLanguage("");
    },
  });

  const handleTranslate = () => {
    if (inputText.trim() && targetLanguage) {
      translateMutation.mutate({
        text: inputText.trim(),
        targetLanguage,
      });
    }
  };

  const languages = [
    "Spanish",
    "French", 
    "German",
    "Italian",
    "Portuguese",
    "Chinese",
    "Japanese",
    "Korean",
    "Russian",
    "Arabic"
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Waves className="h-8 w-8 text-blue-600" />
        <h1 className="text-3xl font-bold">Pond Translator</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>New Translation</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="input-text">Text to Translate</Label>
            <Textarea
              id="input-text"
              placeholder="Enter text to translate..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="min-h-20"
            />
          </div>
          
          <div>
            <Label htmlFor="target-language">Target Language</Label>
            <Select value={targetLanguage} onValueChange={setTargetLanguage}>
              <SelectTrigger>
                <SelectValue placeholder="Select target language" />
              </SelectTrigger>
              <SelectContent>
                {languages.map((lang) => (
                  <SelectItem key={lang} value={lang}>
                    {lang}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button 
            onClick={handleTranslate}
            disabled={!inputText.trim() || !targetLanguage || translateMutation.isPending}
            className="w-full"
          >
            {translateMutation.isPending ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Translating...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Translate
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Translation History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {isLoading ? (
              <p>Loading translations...</p>
            ) : translations?.length ? (
              translations.map((translation) => (
                <div
                  key={translation.id}
                  className="border rounded-lg p-4 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{translation.language}</span>
                    <span
                      className={`px-2 py-1 rounded text-xs ${
                        translation.status === "completed"
                          ? "bg-green-100 text-green-800"
                          : translation.status === "pending"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-red-100 text-red-800"
                      }`}
                    >
                      {translation.status}
                    </span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-muted-foreground">Original</p>
                      <p className="text-sm">{translation.original}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Translation</p>
                      <p className="text-sm">
                        {translation.status === "pending" ? (
                          <span className="italic text-muted-foreground">Processing...</span>
                        ) : (
                          translation.translated
                        )}
                      </p>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {translation.timestamp.toLocaleString()}
                  </p>
                </div>
              ))
            ) : (
              <p className="text-muted-foreground">No translations yet</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}