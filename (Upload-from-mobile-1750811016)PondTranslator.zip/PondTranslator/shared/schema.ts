import { pgTable, text, timestamp, real, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

// Pond Translation Table
export const pondTranslations = pgTable("pond_translations", {
  id: text("id").primaryKey().$defaultFn(() => Math.random().toString(36).substr(2, 9)),
  original: text("original").notNull(),
  translated: text("translated").notNull(),
  language: text("language").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  status: text("status", { enum: ["pending", "completed", "error"] }).notNull(),
});

export const insertPondTranslationSchema = createInsertSchema(pondTranslations).omit({ 
  id: true, 
  timestamp: true 
});
export type PondTranslation = typeof pondTranslations.$inferSelect;
export type InsertPondTranslation = typeof pondTranslations.$inferInsert;

// Node Monitoring Table
export const nodes = pgTable("nodes", {
  id: text("id").primaryKey().$defaultFn(() => Math.random().toString(36).substr(2, 9)),
  name: text("name").notNull(),
  status: text("status", { enum: ["online", "offline", "warning", "error"] }).notNull(),
  cpu: real("cpu").notNull(),
  memory: real("memory").notNull(),
  disk: real("disk").notNull(),
  network: real("network").notNull(),
  uptime: integer("uptime").notNull(),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

export const insertNodeSchema = createInsertSchema(nodes).omit({ 
  id: true, 
  lastUpdated: true 
});
export type Node = typeof nodes.$inferSelect;
export type InsertNode = typeof nodes.$inferInsert;

// Chat Message Table
export const chatMessages = pgTable("chat_messages", {
  id: text("id").primaryKey().$defaultFn(() => Math.random().toString(36).substr(2, 9)),
  content: text("content").notNull(),
  sender: text("sender").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  type: text("type", { enum: ["user", "system", "pond"] }).notNull(),
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({ 
  id: true, 
  timestamp: true 
});
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;